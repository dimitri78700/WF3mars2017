</div>
        <div class="container">
            <hr>
            <footer>
                <div class="row">
                    <div class="col-lg-12">
                        <a href="https://www.cnil.fr/">Mentions légales</a><br><a href="https://fr.wikipedia.org/wiki/Conditions_g%C3%A9n%C3%A9rales_de_vente">Conditions générales de ventes</a><br><br>
                        <aside>copyright &copy; Sallea - 2017</aside>
                    </div>
                </div>
            </footer>
        </div>
    <script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
    <script src="js/script.js"></script>
    <script src="./bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js?t=20130302"></script>

  </body>
</html>
